<?php
namespace App\Http\Controllers\Accounting;

use App\Http\Controllers\Controller;
use App\Models\CashBankAccount;
use App\Models\Guarantor;
use App\Models\Patient;
use App\Models\Receipt;
use App\Models\ServiceUnit;
use App\Services\JournalService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ReceiptController extends Controller
{
    public function index(Request $request)
    {
        $q = Receipt::with(['patient','serviceUnit','guarantor','cashier','cashBankAccount'])->latest('transaction_date');
        if ($request->filled('date_from')) $q->whereDate('transaction_date','>=',$request->date_from);
        if ($request->filled('date_to')) $q->whereDate('transaction_date','<=',$request->date_to);
        if ($request->filled('unit')) $q->where('service_unit_id',$request->unit);
        if ($request->filled('guarantor')) $q->where('guarantor_id',$request->guarantor);
        if ($request->filled('bpjs')) $q->whereHas('guarantor', fn($x) => $x->where('is_bpjs', $request->bpjs === '1'));

        return view('accounting.receipts.index', [
            'receipts'=>$q->paginate(25)->withQueryString(),
            'units'=>ServiceUnit::all(),
            'guarantors'=>Guarantor::orderBy('is_bpjs','desc')->orderBy('name')->get(),
        ]);
    }

    public function edit(Receipt $receipt)
    {
        return view('accounting.receipts.edit', [
            'receipt'=>$receipt,
            'patients'=>Patient::orderBy('name')->get(),
            'units'=>ServiceUnit::where('is_active',true)->get(),
            'guarantors'=>Guarantor::where('is_active',true)->orderBy('is_bpjs','desc')->orderBy('name')->get(),
            'cashBanks'=>CashBankAccount::where('is_active',true)->get(),
        ]);
    }

    public function update(Request $request, Receipt $receipt)
    {
        $data=$request->validate([
            'transaction_date'=>['required','date'],
            'patient_id'=>['required', Rule::exists('patients','id')->whereNull('deleted_at')],
            'service_unit_id'=>['required','exists:service_units,id'],
            'guarantor_id'=>['required','exists:guarantors,id'],
            'service_type'=>['nullable','string','max:100'],
            'amount'=>['required','numeric','gt:0'],
            'payment_method'=>['required','in:CASH,TRANSFER,QRIS,CARD,GUARANTOR'],
            'cash_bank_account_id'=>['nullable','required_unless:payment_method,GUARANTOR','exists:cash_bank_accounts,id'],
            'notes'=>['nullable','string','max:500'],
            'status'=>['required','in:ACTIVE,CANCELLED'],
        ]);

        if ($receipt->journal()->exists()) return back()->withErrors(['transaction'=>'Transaksi yang sudah memiliki jurnal tidak dapat diubah.']);
        if ($receipt->referralExpense()->exists() && (int)$data['patient_id'] !== (int)$receipt->patient_id) {
            return back()->withErrors(['patient_id'=>'Pasien tidak dapat diganti karena sesi ini sudah memiliki referal.']);
        }

        $patient = Patient::findOrFail($data['patient_id']);
        $data['medical_record_no'] = $patient->medical_record_no;
        $data['patient_name'] = $patient->name;
        $receipt->update($data);

        return redirect()->route('accounting.receipts.index')->with('success','Penerimaan diperbarui.');
    }

    public function generateJournal(Receipt $receipt, JournalService $service, Request $request)
    {
        $service->fromReceipt($receipt,$request->user()->id);
        return back()->with('success','Jurnal penerimaan berhasil dibuat.');
    }
}
