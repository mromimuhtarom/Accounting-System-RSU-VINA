<?php
namespace App\Http\Controllers\Accounting;
use App\Http\Controllers\Controller;
use App\Models\CashBankAccount;
use App\Models\ChartAccount;
use App\Models\Expense;
use App\Models\ExpenseCategory;
use App\Services\JournalService;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
class ExpenseController extends Controller {
    public function index(Request $request){$q=Expense::with(['category','account','cashBankAccount','patient','receipt'])->latest('expense_date');if($request->filled('date_from'))$q->whereDate('expense_date','>=',$request->date_from);if($request->filled('date_to'))$q->whereDate('expense_date','<=',$request->date_to);return view('accounting.expenses.index',['expenses'=>$q->paginate(25)->withQueryString()]);}
    public function create(){return view('accounting.expenses.create',$this->formData());}
    public function store(Request $request){$data=$this->validated($request);$data['expense_no']='EXP-'.now()->format('YmdHis').'-'.random_int(100,999);$data['expense_type']='GENERAL';$data['created_by']=$request->user()->id;$data['status']='ACTIVE';if($request->hasFile('attachment'))$data['attachment_path']=$request->file('attachment')->store('expenses','public');Expense::create($data);return redirect()->route('accounting.pengeluaran.index')->with('success','Pengeluaran berhasil disimpan.');}
    public function edit(Expense $pengeluaran){if($pengeluaran->expense_type==='REFERRAL')return redirect()->route('accounting.referrals.edit',$pengeluaran);if($pengeluaran->journal()->exists())return redirect()->route('accounting.pengeluaran.index')->withErrors(['expense'=>'Pengeluaran yang sudah dijurnal tidak dapat diubah.']);return view('accounting.expenses.edit',array_merge($this->formData(),['expense'=>$pengeluaran]));}
    public function update(Request $request,Expense $pengeluaran){if($pengeluaran->expense_type==='REFERRAL')abort(404);if($pengeluaran->journal()->exists())return back()->withErrors(['expense'=>'Pengeluaran yang sudah dijurnal tidak dapat diubah.']);$pengeluaran->update($this->validated($request));return redirect()->route('accounting.pengeluaran.index')->with('success','Pengeluaran diperbarui.');}
    public function generateJournal(Expense $expense,JournalService $service,Request $request){$service->fromExpense($expense,$request->user()->id);return back()->with('success','Jurnal pengeluaran berhasil dibuat.');}
    private function formData(){return ['categories'=>ExpenseCategory::where('is_active',true)->where('code','!=','REFERAL')->get(),'accounts'=>ChartAccount::where('is_active',true)->where('type','EXPENSE')->where('code','!=','5-1014')->get(),'cashBanks'=>CashBankAccount::where('is_active',true)->get()];}
    private function validated(Request $request){$data=$request->validate(['expense_date'=>['required','date'],'expense_category_id'=>['required','exists:expense_categories,id'],'chart_account_id'=>['required','exists:chart_accounts,id'],'description'=>['required','string','max:500'],'amount'=>['required','numeric','gt:0'],'payment_method'=>['required','in:CASH,TRANSFER,QRIS,CARD'],'cash_bank_account_id'=>['required','exists:cash_bank_accounts,id'],'reference_no'=>['nullable','string','max:100'],'attachment'=>['nullable','file','max:5120']]);$category=ExpenseCategory::findOrFail($data['expense_category_id']);if($category->code==='REFERAL')throw ValidationException::withMessages(['expense_category_id'=>'Kategori Referal harus diinput melalui module Pengeluaran Referal.']);return $data;}
}
