<?php

namespace App\Http\Controllers\Cashier;

use App\Http\Controllers\Controller;
use App\Models\CashBankAccount;
use App\Models\Guarantor;
use App\Models\Patient;
use App\Models\Receipt;
use App\Models\ServiceUnit;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ReceiptController extends Controller
{
    public function index(Request $request)
    {
        $query = Receipt::with(['patient', 'serviceUnit', 'guarantor', 'cashBankAccount', 'journal'])
            ->where('cashier_id', $request->user()->id)
            ->latest('transaction_date')
            ->latest('id');

        if ($request->filled('date_from')) $query->whereDate('transaction_date', '>=', $request->date_from);
        if ($request->filled('date_to')) $query->whereDate('transaction_date', '<=', $request->date_to);

        if ($request->filled('search')) {
            $search = trim((string) $request->search);
            $query->where(function ($q) use ($search) {
                $q->where('transaction_no', 'like', "%{$search}%")
                    ->orWhere('medical_record_no', 'like', "%{$search}%")
                    ->orWhere('patient_name', 'like', "%{$search}%")
                    ->orWhereHas('patient', function ($patient) use ($search) {
                        $patient->where('medical_record_no', 'like', "%{$search}%")
                            ->orWhere('name', 'like', "%{$search}%");
                    });
            });
        }

        return view('cashier.receipts.index', [
            'receipts' => $query->paginate(20)->withQueryString(),
        ]);
    }

    public function create()
    {
        return view('cashier.receipts.create', $this->formData());
    }

    public function store(Request $request)
    {
        $data = $this->validatedData($request);
        $patient = Patient::findOrFail($data['patient_id']);
        $data['medical_record_no'] = $patient->medical_record_no;
        $data['patient_name'] = $patient->name;
        $data['transaction_no'] = 'RCV-' . now()->format('YmdHis') . '-' . random_int(100, 999);
        $data['cashier_id'] = $request->user()->id;
        $data['status'] = 'ACTIVE';

        Receipt::create($data);

        return redirect()->route('cashier.receipts.index')->with('success', 'Penerimaan berhasil disimpan.');
    }

    public function edit(Request $request, Receipt $receipt)
    {
        $this->ensureOwnedByCashier($request, $receipt);
        if ($receipt->journal()->exists()) {
            return redirect()->route('cashier.receipts.index')->with('error', 'Transaksi sudah dijurnal oleh Accounting sehingga tidak dapat diedit oleh Kasir.');
        }

        return view('cashier.receipts.edit', array_merge(['receipt' => $receipt], $this->formData()));
    }

    public function update(Request $request, Receipt $receipt)
    {
        $this->ensureOwnedByCashier($request, $receipt);
        if ($receipt->journal()->exists()) {
            return redirect()->route('cashier.receipts.index')->with('error', 'Transaksi sudah dijurnal oleh Accounting sehingga tidak dapat diedit oleh Kasir.');
        }

        $data = $this->validatedData($request);
        $patient = Patient::findOrFail($data['patient_id']);
        $data['medical_record_no'] = $patient->medical_record_no;
        $data['patient_name'] = $patient->name;
        $receipt->update($data);

        return redirect()->route('cashier.receipts.index')->with('success', 'Penerimaan berhasil diperbarui.');
    }

    public function destroy(Request $request, Receipt $receipt)
    {
        $this->ensureOwnedByCashier($request, $receipt);
        if ($receipt->journal()->exists()) {
            return redirect()->route('cashier.receipts.index')->with('error', 'Transaksi sudah dijurnal oleh Accounting sehingga tidak dapat dihapus oleh Kasir.');
        }
        if ($receipt->referralExpense()->exists()) {
            return redirect()->route('cashier.receipts.index')->with('error', 'Transaksi sudah memiliki pengeluaran referal sehingga tidak dapat dihapus.');
        }

        $receipt->delete();
        return redirect()->route('cashier.receipts.index')->with('success', 'Penerimaan berhasil dihapus.');
    }

    private function ensureOwnedByCashier(Request $request, Receipt $receipt): void
    {
        if ($request->user()->accountingRole() === 'IT') return;
        abort_unless((int) $receipt->cashier_id === (int) $request->user()->id, 403);
    }

    private function formData(): array
    {
        return [
            'patients' => Patient::orderBy('name')->get(),
            'units' => ServiceUnit::where('is_active', true)->orderBy('name')->get(),
            'guarantors' => Guarantor::where('is_active', true)->orderBy('is_bpjs', 'desc')->orderBy('name')->get(),
            'cashBanks' => CashBankAccount::where('is_active', true)->orderBy('name')->get(),
        ];
    }

    private function validatedData(Request $request): array
    {
        return $request->validate([
            'transaction_date' => ['required', 'date'],
            'patient_id' => ['required', Rule::exists('patients', 'id')->whereNull('deleted_at')],
            'service_unit_id' => ['required', 'exists:service_units,id'],
            'guarantor_id' => ['required', 'exists:guarantors,id'],
            'service_type' => ['nullable', 'string', 'max:100'],
            'amount' => ['required', 'numeric', 'gt:0'],
            'payment_method' => ['required', 'in:CASH,TRANSFER,QRIS,CARD,GUARANTOR'],
            'cash_bank_account_id' => ['nullable', 'required_unless:payment_method,GUARANTOR', 'exists:cash_bank_accounts,id'],
            'notes' => ['nullable', 'string', 'max:500'],
        ]);
    }
}
