@extends('layouts.app')
@section('content')
<div class="page-head">
    <div>
        <h1 class="page-title">Penerimaan Saya</h1>
        <p class="page-sub">Lihat dan koreksi transaksi penerimaan yang Anda input.</p>
    </div>
    <a class="btn primary" href="{{ route('cashier.receipts.create') }}">＋ Input Penerimaan</a>
</div>

<div class="card">
    <form class="form-grid" method="GET" action="{{ route('cashier.receipts.index') }}">
        <div class="field">
            <label>Dari Tanggal</label>
            <input type="date" name="date_from" value="{{ request('date_from') }}">
        </div>
        <div class="field">
            <label>Sampai Tanggal</label>
            <input type="date" name="date_to" value="{{ request('date_to') }}">
        </div>
        <div class="field">
            <label>Cari</label>
            <input name="search" value="{{ request('search') }}" placeholder="No transaksi, No RM, pasien">
        </div>
        <div style="align-self:end;display:flex;gap:8px">
            <button class="btn" type="submit">Filter</button>
            <a class="btn" href="{{ route('cashier.receipts.index') }}">Reset</a>
        </div>
    </form>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>No Transaksi</th>
                    <th>Pasien</th>
                    <th>Unit</th>
                    <th>Penjamin</th>
                    <th>Nominal</th>
                    <th>Status Jurnal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            @forelse($receipts as $r)
                <tr>
                    <td>{{ $r->transaction_date->format('d-m-Y') }}</td>
                    <td><strong>{{ $r->transaction_no }}</strong></td>
                    <td>
                        <strong>{{ $r->patient?->name ?? $r->patient_name }}</strong>
                        @if($r->patient?->medical_record_no ?? $r->medical_record_no)<div class="muted">RM: {{ $r->patient?->medical_record_no ?? $r->medical_record_no }}</div>@endif
                    </td>
                    <td>{{ $r->serviceUnit?->name }}</td>
                    <td>
                        {{ $r->guarantor?->name }}
                        @if($r->guarantor?->is_bpjs)<span class="badge bpjs">BPJS</span>@endif
                    </td>
                    <td class="money">Rp {{ number_format($r->amount,0,',','.') }}</td>
                    <td>
                        @if($r->journal)
                            <span class="badge">Sudah Dijurnal</span>
                        @else
                            <span class="badge" style="background:#ecfdf3;color:#15803d">Belum Dijurnal</span>
                        @endif
                    </td>
                    <td>
                        @if(!$r->journal)
                            <div class="actions">
                                <a class="btn" href="{{ route('cashier.receipts.edit',$r) }}">Edit</a>
                                <form method="POST" action="{{ route('cashier.receipts.destroy',$r) }}" onsubmit="return confirm('Hapus transaksi {{ $r->transaction_no }}? Data yang dihapus tidak dapat dikembalikan.')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn danger" type="submit">Delete</button>
                                </form>
                            </div>
                        @else
                            <span class="muted">Terkunci</span>
                        @endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="8" class="muted">Belum ada transaksi penerimaan yang Anda input.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    <div class="pagination">{{ $receipts->links() }}</div>
</div>
@endsection
