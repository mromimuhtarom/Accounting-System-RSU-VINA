@extends('layouts.app')
@section('content')
<div class="page-head"><div><h1 class="page-title">Penerimaan</h1><p class="page-sub">Monitoring seluruh penerimaan pasien termasuk BPJS.</p></div></div>
<div class="card">
<form class="form-grid" method="GET">
<div class="field"><label>Dari</label><input type="date" name="date_from" value="{{ request('date_from') }}"></div>
<div class="field"><label>Sampai</label><input type="date" name="date_to" value="{{ request('date_to') }}"></div>
<div class="field"><label>Unit</label><select name="unit"><option value="">Semua Unit</option>@foreach($units as $x)<option value="{{ $x->id }}" @selected(request('unit')==$x->id)>{{ $x->name }}</option>@endforeach</select></div>
<div class="field"><label>Penjamin</label><select name="guarantor"><option value="">Semua Penjamin</option>@foreach($guarantors as $x)<option value="{{ $x->id }}" @selected(request('guarantor')==$x->id)>{{ $x->name }}</option>@endforeach</select></div>
<div class="field"><label>Jenis</label><select name="bpjs"><option value="">Semua</option><option value="1" @selected(request('bpjs')==='1')>BPJS</option><option value="0" @selected(request('bpjs')==='0')>Non-BPJS</option></select></div>
<div style="align-self:end"><button class="btn" type="submit">Filter</button></div>
</form>
</div>
<div class="card">
<div class="table-wrap"><table><thead><tr><th>Tanggal</th><th>No</th><th>Pasien</th><th>Unit</th><th>Penjamin</th><th>Kasir</th><th>Nominal</th><th>Aksi</th></tr></thead><tbody>
@forelse($receipts as $r)<tr><td>{{ $r->transaction_date->format('d-m-Y') }}</td><td><strong>{{ $r->transaction_no }}</strong></td><td>{{ $r->patient?->name ?? $r->patient_name }}</td><td>{{ $r->serviceUnit->name }}</td><td>{{ $r->guarantor->name }} @if($r->guarantor->is_bpjs)<span class="badge bpjs">BPJS</span>@endif</td><td>{{ $r->cashier->name }}</td><td class="money">Rp {{ number_format($r->amount,0,',','.') }}</td><td><div class="actions"><a class="btn" href="{{ route('accounting.receipts.edit',$r) }}">Edit</a>@if(!$r->journal)<form method="POST" action="{{ route('accounting.receipts.journal',$r) }}">@csrf<button class="btn">Buat Jurnal</button></form>@else<span class="badge">Sudah dijurnal</span>@endif</div></td></tr>@empty<tr><td colspan="8" class="muted">Belum ada transaksi.</td></tr>@endforelse
</tbody></table></div><div class="pagination">{{ $receipts->links() }}</div>
</div>
@endsection
