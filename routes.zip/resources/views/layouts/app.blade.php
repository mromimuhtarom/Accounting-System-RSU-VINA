<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta name="theme-color" content="#071f2d">
<title>{{ $title ?? 'Accounting System' }} | {{ config('accounting.hospital_name', 'RS. Vina Estetica') }}</title>
<link rel="stylesheet" href="{{ asset('public/css/accounting.css') }}">
<link rel="stylesheet" href="{{ asset('css/searchable-select.css') }}?v=20260819-2">
</head>
<body>
<div class="page-transition" id="pageTransition" aria-hidden="true">
    <div class="page-transition-inner">
        <div class="transition-logo-wrap"><img src="{{ asset('public/images/vina-estetica-logo.png') }}" alt=""></div>
        <div class="transition-copy">
            <strong>Vina Estetica</strong>
            <span>Accounting System</span>
        </div>
    </div>
</div>
@php($role = strtoupper(trim((string) (auth()->user()?->accountingRole() ?? ''))))
<div class="app-shell">
    <div class="mobile-overlay" id="mobileOverlay" onclick="toggleSidebar()"></div>
    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <img src="{{ asset('images/vina-estetica-logo.png') }}" alt="Logo RS. Vina Estetica">
            <div>
                <div class="brand-title">{{ config('accounting.hospital_name', 'RS. Vina Estetica') }}</div>
                <div class="brand-sub">Accounting System</div>
            </div>
        </div>

        <nav class="menu">
            <a class="{{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}"><span class="menu-icon">⌂</span> Dashboard</a>

            @if(in_array($role,['KASIR','IT']))
                <div class="menu-label">Pasien</div>
                <a class="{{ request()->routeIs('cashier.patients.*') ? 'active' : '' }}" href="{{ route('cashier.patients.index') }}"><span class="menu-icon">♙</span> Data Pasien</a>
            @endif

            @if($role === 'KASIR')
                <div class="menu-label">Transaksi</div>
                <a class="{{ request()->routeIs('cashier.receipts.index') || request()->routeIs('cashier.receipts.edit') ? 'active' : '' }}" href="{{ route('cashier.receipts.index') }}"><span class="menu-icon">↙</span> Penerimaan</a>
                <a class="{{ request()->routeIs('cashier.receipts.create') ? 'active' : '' }}" href="{{ route('cashier.receipts.create') }}"><span class="menu-icon">＋</span> Input Penerimaan</a>
            @endif

            @if(in_array($role,['ACCOUNTING','IT']))
                <div class="menu-label">Transaksi</div>
                <a class="{{ request()->routeIs('accounting.receipts.*') ? 'active' : '' }}" href="{{ route('accounting.receipts.index') }}"><span class="menu-icon">↙</span> Penerimaan</a>
                <a class="{{ request()->routeIs('accounting.pengeluaran.*') ? 'active' : '' }}" href="{{ route('accounting.pengeluaran.index') }}"><span class="menu-icon">↗</span> Pengeluaran</a>
                <a class="{{ request()->routeIs('accounting.referrals.*') ? 'active' : '' }}" href="{{ route('accounting.referrals.index') }}"><span class="menu-icon">↗</span> Referal</a>
                <a class="{{ request()->routeIs('accounting.jurnal.*') ? 'active' : '' }}" href="{{ route('accounting.jurnal.index') }}"><span class="menu-icon">▤</span> Jurnal</a>

                <div class="menu-label">Master Data</div>
                <a href="{{ route('accounting.master.index','accounts') }}"><span class="menu-icon">▦</span> Chart of Accounts</a>
                <a href="{{ route('accounting.master.index','units') }}"><span class="menu-icon">✚</span> Unit Pelayanan</a>
                <a href="{{ route('accounting.master.index','guarantors') }}"><span class="menu-icon">◇</span> Penjamin</a>
                <a href="{{ route('accounting.master.index','cash-banks') }}"><span class="menu-icon">▣</span> Kas & Bank</a>
                <a href="{{ route('accounting.master.index','expense-categories') }}"><span class="menu-icon">◇</span> Kategori Pengeluaran</a>
                <a href="{{ route('accounting.master.index','financial-groups') }}"><span class="menu-icon">▦</span> Group Laporan</a>
            @endif

            @if(in_array($role,['ACCOUNTING','ATASAN','IT']))
                <div class="menu-label">Laporan</div>
                <a class="{{ request()->routeIs('reports.monthly') ? 'active' : '' }}" href="{{ route('reports.monthly') }}"><span class="menu-icon">▦</span> Laporan Bulanan</a>
                <a class="{{ request()->routeIs('reports.yearly') ? 'active' : '' }}" href="{{ route('reports.yearly') }}"><span class="menu-icon">▦</span> Laporan Tahunan</a>
                <a class="{{ request()->routeIs('reports.income') ? 'active' : '' }}" href="{{ route('reports.income') }}"><span class="menu-icon">▧</span> Detail Penerimaan</a>
                <a class="{{ request()->routeIs('reports.expense') ? 'active' : '' }}" href="{{ route('reports.expense') }}"><span class="menu-icon">▧</span> Detail Pengeluaran</a>
                <a class="{{ request()->routeIs('reports.ledger') ? 'active' : '' }}" href="{{ route('reports.ledger') }}"><span class="menu-icon">≡</span> General Ledger</a>
                <a class="{{ request()->routeIs('reports.trial-balance') ? 'active' : '' }}" href="{{ route('reports.trial-balance') }}"><span class="menu-icon">▥</span> Trial Balance</a>
            @endif

            @if($role === 'IT')
                <div class="menu-label">System</div>
                <a class="{{ request()->routeIs('it.users.*') ? 'active' : '' }}" href="{{ route('it.users.index') }}"><span class="menu-icon">♙</span> Manajemen Akun</a>
            @endif
        </nav>
        <div class="sidebar-footer">
            {{ config('accounting.hospital_name', 'RS. Vina Estetica') }}<br>
            Sistem Informasi Akuntansi
        </div>
    </aside>

    <main class="main">
        <header class="topbar">
            <div class="top-left">
                <button class="mobile-toggle" type="button" onclick="toggleSidebar()">☰</button>
                <div class="search-pill">⌕ &nbsp; Cari menu, transaksi, laporan...</div>
            </div>
            <div class="top-user">
                <div class="avatar">{{ strtoupper(substr(auth()->user()->name ?? 'U',0,1)) }}</div>
                <div>
                    <div class="user-name">{{ auth()->user()->name ?? '' }}</div>
                    <div class="user-role">{{ $role === 'IT' ? 'IT' : ucfirst(strtolower($role ?? '')) }}</div>
                </div>
                <form method="POST" action="{{ route('logout') }}">@csrf<button class="logout-btn" type="submit" title="Logout">↪</button></form>
            </div>
        </header>

        <section class="content">
            @if(session('success'))<div class="success">{{ session('success') }}</div>@endif
            @if(session('error'))<div class="error">{{ session('error') }}</div>@endif
            @if($errors->any())<div class="error"><strong>Periksa data:</strong><ul>@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul></div>@endif
            @yield('content')
        </section>
    </main>
</div>
<script>
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');document.getElementById('mobileOverlay').classList.toggle('show')}
</script>
<script src="{{ asset('public/js/accounting-ui.js') }}?v=20260819-design-1"></script>
<script src="{{ asset('js/searchable-select.js') }}?v=20260819-2"></script>
@stack('scripts')
</body>
</html>
