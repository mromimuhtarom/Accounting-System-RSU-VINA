@extends('layouts.app')

@section('content')
@php
    $monthShort = [1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'Mei',6=>'Jun',7=>'Jul',8=>'Agu',9=>'Sep',10=>'Okt',11=>'Nov',12=>'Des'];
@endphp

<div class="page-head">
    <div>
        <h1 class="page-title">Laporan Keuangan Tahunan</h1>
        <p class="page-sub">Rekap Januari sampai Desember dengan group dan subtotal seperti laporan Excel.</p>
    </div>
    <form method="GET" class="period-filter compact-filter">
        <select name="year">
            @for($y = now()->year + 1; $y >= now()->year - 7; $y--)
                <option value="{{ $y }}" @selected($year === $y)>{{ $y }}</option>
            @endfor
        </select>
        <button class="btn primary" type="submit">Tampilkan</button>
    </form>
</div>

<div class="stats-grid report-stats">
    <div class="card stat-card"><div class="stat-label">Total Pemasukan {{ $year }}</div><div class="stat">Rp {{ number_format($totalIncome, 0, ',', '.') }}</div><div class="stat-icon green">↙</div></div>
    <div class="card stat-card"><div class="stat-label">Total Pengeluaran {{ $year }}</div><div class="stat">Rp {{ number_format($totalExpense, 0, ',', '.') }}</div><div class="stat-icon red">↗</div></div>
    <div class="card stat-card"><div class="stat-label">Surplus / (Defisit)</div><div class="stat {{ $surplus < 0 ? 'text-danger' : 'text-positive' }}">Rp {{ number_format($surplus, 0, ',', '.') }}</div><div class="stat-icon blue">↗</div></div>
</div>

<div class="card yearly-card">
    <div class="report-section-title"><span class="report-dot income"></span> PEMASUKAN TAHUN {{ $year }}</div>
    <div class="table-responsive yearly-table-wrap">
        <table class="yearly-table">
            <thead>
                <tr><th>Uraian</th>@foreach($monthShort as $name)<th class="money">{{ $name }}</th>@endforeach<th class="money total-col">Total</th></tr>
            </thead>
            <tbody>
                @foreach($income as $group)
                    <tr class="group-row"><td>{{ $group['name'] }}</td>@foreach(range(1,12) as $m)<td class="money">{{ number_format($group['months'][$m] ?? 0, 0, ',', '.') }}</td>@endforeach<td class="money total-col">{{ number_format($group['total'], 0, ',', '.') }}</td></tr>
                    @foreach($group['details'] as $detail)
                        <tr><td class="detail-label">{{ $detail['label'] }}</td>@foreach(range(1,12) as $m)<td class="money">{{ number_format($detail['months'][$m] ?? 0, 0, ',', '.') }}</td>@endforeach<td class="money total-col">{{ number_format($detail['total'], 0, ',', '.') }}</td></tr>
                    @endforeach
                    <tr class="subtotal-row"><td>Subtotal {{ $group['name'] }}</td>@foreach(range(1,12) as $m)<td class="money">{{ number_format($group['months'][$m] ?? 0, 0, ',', '.') }}</td>@endforeach<td class="money total-col">{{ number_format($group['total'], 0, ',', '.') }}</td></tr>
                @endforeach
                <tr class="grand-row"><td>TOTAL PEMASUKAN</td>@foreach(range(1,12) as $m)<td class="money">{{ number_format($incomeMonths[$m] ?? 0, 0, ',', '.') }}</td>@endforeach<td class="money total-col">{{ number_format($totalIncome, 0, ',', '.') }}</td></tr>
            </tbody>
        </table>
    </div>
</div>

<div class="card yearly-card">
    <div class="report-section-title"><span class="report-dot expense"></span> PENGELUARAN TAHUN {{ $year }}</div>
    <div class="table-responsive yearly-table-wrap">
        <table class="yearly-table">
            <thead>
                <tr><th>Uraian</th>@foreach($monthShort as $name)<th class="money">{{ $name }}</th>@endforeach<th class="money total-col">Total</th></tr>
            </thead>
            <tbody>
                @foreach($expense as $group)
                    <tr class="group-row expense-group"><td>{{ $group['name'] }}</td>@foreach(range(1,12) as $m)<td class="money">{{ number_format($group['months'][$m] ?? 0, 0, ',', '.') }}</td>@endforeach<td class="money total-col">{{ number_format($group['total'], 0, ',', '.') }}</td></tr>
                    @foreach($group['details'] as $detail)
                        <tr><td class="detail-label">{{ $detail['label'] }}</td>@foreach(range(1,12) as $m)<td class="money">{{ number_format($detail['months'][$m] ?? 0, 0, ',', '.') }}</td>@endforeach<td class="money total-col">{{ number_format($detail['total'], 0, ',', '.') }}</td></tr>
                    @endforeach
                    <tr class="subtotal-row"><td>Subtotal {{ $group['name'] }}</td>@foreach(range(1,12) as $m)<td class="money">{{ number_format($group['months'][$m] ?? 0, 0, ',', '.') }}</td>@endforeach<td class="money total-col">{{ number_format($group['total'], 0, ',', '.') }}</td></tr>
                @endforeach
                <tr class="grand-row expense-grand"><td>TOTAL PENGELUARAN</td>@foreach(range(1,12) as $m)<td class="money">{{ number_format($expenseMonths[$m] ?? 0, 0, ',', '.') }}</td>@endforeach<td class="money total-col">{{ number_format($totalExpense, 0, ',', '.') }}</td></tr>
            </tbody>
        </table>
    </div>
</div>

<div class="card yearly-card result-card">
    <div class="report-section-title">RINGKASAN HASIL {{ $year }}</div>
    <div class="table-responsive yearly-table-wrap">
        <table class="yearly-table summary-table">
            <thead><tr><th>Uraian</th>@foreach($monthShort as $name)<th class="money">{{ $name }}</th>@endforeach<th class="money total-col">Total</th></tr></thead>
            <tbody>
                <tr><td>Total Pemasukan</td>@foreach(range(1,12) as $m)<td class="money">{{ number_format($incomeMonths[$m] ?? 0, 0, ',', '.') }}</td>@endforeach<td class="money total-col">{{ number_format($totalIncome, 0, ',', '.') }}</td></tr>
                <tr><td>Total Pengeluaran</td>@foreach(range(1,12) as $m)<td class="money">{{ number_format($expenseMonths[$m] ?? 0, 0, ',', '.') }}</td>@endforeach<td class="money total-col">{{ number_format($totalExpense, 0, ',', '.') }}</td></tr>
                <tr class="grand-result-row"><td>SURPLUS / (DEFISIT)</td>@foreach(range(1,12) as $m)<td class="money {{ ($surplusMonths[$m] ?? 0) < 0 ? 'text-danger' : 'text-positive' }}">{{ number_format($surplusMonths[$m] ?? 0, 0, ',', '.') }}</td>@endforeach<td class="money total-col {{ $surplus < 0 ? 'text-danger' : 'text-positive' }}">{{ number_format($surplus, 0, ',', '.') }}</td></tr>
            </tbody>
        </table>
    </div>
</div>
@endsection
