@extends('layouts.app')

@section('content')
@php
    $monthNames = [1=>'Januari',2=>'Februari',3=>'Maret',4=>'April',5=>'Mei',6=>'Juni',7=>'Juli',8=>'Agustus',9=>'September',10=>'Oktober',11=>'November',12=>'Desember'];
@endphp

<div class="page-head">
    <div>
        <h1 class="page-title">Laporan Keuangan Bulanan</h1>
        <p class="page-sub">Ringkasan pemasukan, pengeluaran, dan subtotal berdasarkan group laporan.</p>
    </div>
    <form method="GET" class="period-filter compact-filter">
        <select name="month">
            @foreach($monthNames as $number => $name)
                <option value="{{ $number }}" @selected($month === $number)>{{ $name }}</option>
            @endforeach
        </select>
        <select name="year">
            @for($y = now()->year + 1; $y >= now()->year - 7; $y--)
                <option value="{{ $y }}" @selected($year === $y)>{{ $y }}</option>
            @endfor
        </select>
        <button class="btn primary" type="submit">Tampilkan</button>
    </form>
</div>

<div class="stats-grid report-stats">
    <div class="card stat-card">
        <div class="stat-label">Total Pemasukan</div>
        <div class="stat">Rp {{ number_format($totalIncome, 0, ',', '.') }}</div>
        <div class="stat-note">{{ $monthNames[$month] }} {{ $year }}</div>
        <div class="stat-icon green">↙</div>
    </div>
    <div class="card stat-card">
        <div class="stat-label">Total Pengeluaran</div>
        <div class="stat">Rp {{ number_format($totalExpense, 0, ',', '.') }}</div>
        <div class="stat-note">{{ $monthNames[$month] }} {{ $year }}</div>
        <div class="stat-icon red">↗</div>
    </div>
    <div class="card stat-card">
        <div class="stat-label">Surplus / (Defisit)</div>
        <div class="stat {{ $surplus < 0 ? 'text-danger' : 'text-positive' }}">Rp {{ number_format($surplus, 0, ',', '.') }}</div>
        <div class="stat-note">Pemasukan dikurangi pengeluaran</div>
        <div class="stat-icon blue">↗</div>
    </div>
</div>

<div class="report-grid">
    <section>
        <div class="report-section-title"><span class="report-dot income"></span> PEMASUKAN</div>
        @foreach($income as $group)
            <div class="card report-group-card">
                <div class="report-group-head">
                    <div>
                        <div class="group-eyebrow">Pemasukan</div>
                        <h3>{{ $group['name'] }}</h3>
                    </div>
                    <div class="group-total">Rp {{ number_format($group['total'], 0, ',', '.') }}</div>
                </div>
                <div class="table-responsive">
                    <table class="report-table compact">
                        <thead><tr><th>Uraian</th><th class="money">Nominal</th></tr></thead>
                        <tbody>
                            @forelse($group['details'] as $detail)
                                <tr><td>{{ $detail['label'] }}</td><td class="money">Rp {{ number_format($detail['amount'], 0, ',', '.') }}</td></tr>
                            @empty
                                <tr><td colspan="2" class="empty-cell">Belum ada transaksi pada periode ini.</td></tr>
                            @endforelse
                        </tbody>
                        <tfoot><tr><th>Subtotal {{ $group['name'] }}</th><th class="money">Rp {{ number_format($group['total'], 0, ',', '.') }}</th></tr></tfoot>
                    </table>
                </div>
            </div>
        @endforeach
    </section>

    <section>
        <div class="report-section-title"><span class="report-dot expense"></span> PENGELUARAN</div>
        @foreach($expense as $group)
            <div class="card report-group-card">
                <div class="report-group-head">
                    <div>
                        <div class="group-eyebrow expense-text">Pengeluaran</div>
                        <h3>{{ $group['name'] }}</h3>
                    </div>
                    <div class="group-total">Rp {{ number_format($group['total'], 0, ',', '.') }}</div>
                </div>
                <div class="table-responsive">
                    <table class="report-table compact">
                        <thead><tr><th>Uraian</th><th class="money">Nominal</th></tr></thead>
                        <tbody>
                            @forelse($group['details'] as $detail)
                                <tr><td>{{ $detail['label'] }}</td><td class="money">Rp {{ number_format($detail['amount'], 0, ',', '.') }}</td></tr>
                            @empty
                                <tr><td colspan="2" class="empty-cell">Belum ada transaksi pada periode ini.</td></tr>
                            @endforelse
                        </tbody>
                        <tfoot><tr><th>Subtotal {{ $group['name'] }}</th><th class="money">Rp {{ number_format($group['total'], 0, ',', '.') }}</th></tr></tfoot>
                    </table>
                </div>
            </div>
        @endforeach
    </section>
</div>

<div class="card financial-summary">
    <div><span>Total Pemasukan</span><strong>Rp {{ number_format($totalIncome, 0, ',', '.') }}</strong></div>
    <div><span>Total Pengeluaran</span><strong>Rp {{ number_format($totalExpense, 0, ',', '.') }}</strong></div>
    <div class="grand-result"><span>Surplus / (Defisit)</span><strong class="{{ $surplus < 0 ? 'text-danger' : 'text-positive' }}">Rp {{ number_format($surplus, 0, ',', '.') }}</strong></div>
</div>
@endsection
