<?php

namespace App\Http\Controllers\Accounting;

use App\Http\Controllers\Controller;
use App\Models\ChartAccount;
use App\Models\Receipt;
use App\Services\JournalService;
use Illuminate\Http\Request;

class ReceiptController extends Controller
{
    public function index(Request $request)
    {
        $query = Receipt::with([
            'account',
            'cashier',
            'journal',
            'referralExpense',
        ])->latest('transaction_date')
            ->latest('id');

        if ($request->filled('date_from')) {
            $query->whereDate('transaction_date', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('transaction_date', '<=', $request->date_to);
        }

        if ($request->filled('account_id')) {
            $query->where('chart_account_id', $request->account_id);
        }

        if ($request->filled('search')) {
            $search = trim((string) $request->search);

            $query->where(function ($q) use ($search) {
                $q->where('transaction_no', 'like', "%{$search}%")
                    ->orWhere('income_code', 'like', "%{$search}%")
                    ->orWhere('notes', 'like', "%{$search}%")
                    ->orWhere('doctor_name', 'like', "%{$search}%")
                    ->orWhereHas('account', function ($account) use ($search) {
                        $account->where('code', 'like', "%{$search}%")
                            ->orWhere('name', 'like', "%{$search}%");
                    });
            });
        }

        return view('accounting.receipts.index', [
            'receipts' => $query->paginate(10)->withQueryString(),
            'accounts' => $this->accounts(),
        ]);
    }

    public function create()
    {
        return view('accounting.receipts.create', [
            'accounts' => $this->accounts(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $this->validatedData($request);
        $data['transaction_no'] = 'RCV-'
            . now()->format('YmdHis')
            . '-'
            . random_int(100, 999);
        $data['cashier_id'] = $request->user()->id;
        $data['status'] = 'ACTIVE';

        Receipt::create($data);

        return redirect()
            ->route('accounting.receipts.index')
            ->with('success', 'Pemasukan berhasil disimpan.');
    }

    public function edit(Receipt $receipt)
    {
        if ($receipt->journal()->exists()) {
            return redirect()
                ->route('accounting.receipts.index')
                ->withErrors([
                    'transaction' => 'Transaksi yang sudah memiliki jurnal tidak dapat diubah.',
                ]);
        }

        return view('accounting.receipts.edit', [
            'receipt' => $receipt,
            'accounts' => $this->accounts(),
        ]);
    }

    public function update(Request $request, Receipt $receipt)
    {
        if ($receipt->journal()->exists()) {
            return back()->withErrors([
                'transaction' => 'Transaksi yang sudah memiliki jurnal tidak dapat diubah.',
            ]);
        }

        $receipt->update(
            $this->validatedData($request, true)
        );

        return redirect()
            ->route('accounting.receipts.index')
            ->with('success', 'Pemasukan diperbarui.');
    }

    public function destroy(Receipt $receipt)
    {
        if ($receipt->journal()->exists()) {
            return back()->with(
                'error',
                'Pemasukan yang sudah dijurnal tidak dapat dihapus.'
            );
        }

        if ($receipt->referralExpense()->exists()) {
            return back()->with(
                'error',
                'Pemasukan yang sudah memiliki pengeluaran referal tidak dapat dihapus.'
            );
        }

        $receipt->delete();

        return redirect()
            ->route('accounting.receipts.index')
            ->with('success', 'Pemasukan berhasil dihapus.');
    }

    public function generateJournal(
        Receipt $receipt,
        JournalService $service,
        Request $request
    ) {
        $service->fromReceipt(
            $receipt,
            $request->user()->id
        );

        return back()->with(
            'success',
            'Jurnal pemasukan berhasil dibuat.'
        );
    }

    private function validatedData(
        Request $request,
        bool $includeStatus = false
    ): array {
        $rules = [
            'transaction_date' => ['required', 'date'],
            'chart_account_id' => ['required', 'exists:chart_accounts,id'],
            'notes' => ['required', 'string', 'max:1000'],
            'doctor_name' => ['nullable', 'string', 'max:150'],
            'hd' => ['nullable', 'string', 'max:100'],
            'rs' => ['nullable', 'string', 'max:100'],
            'amount' => ['required', 'numeric', 'gt:0'],
        ];

        if ($includeStatus) {
            $rules['status'] = ['required', 'in:ACTIVE,CANCELLED'];
        }

        return $request->validate($rules);
    }

    private function accounts()
    {
        return ChartAccount::where('is_active', true)
            ->orderBy('code')
            ->get();
    }
}
