<?php

namespace App\Http\Controllers\Accounting;

use App\Http\Controllers\Controller;
use App\Models\CashBankAccount;
use App\Models\ChartAccount;
use App\Models\ExpenseCategory;
use App\Models\FinancialGroup;
use App\Models\Guarantor;
use App\Models\ServiceUnit;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class MasterController extends Controller
{
    private array $map = [
        'accounts' => ChartAccount::class,
        'units' => ServiceUnit::class,
        'guarantors' => Guarantor::class,
        'cash-banks' => CashBankAccount::class,
        'expense-categories' => ExpenseCategory::class,
        'financial-groups' => FinancialGroup::class,
    ];

    public function index(Request $request, string $type)
    {
        $this->ensureCanManage($request);

        $model = $this->model($type);
        $sortColumn = in_array($type, ['accounts', 'financial-groups'], true)
            ? 'code'
            : 'name';

        $editingItem = null;

        if ($request->filled('edit')) {
            $editingItem = $model::findOrFail((int) $request->edit);
        }

        return view('accounting.master.index', [
            'type' => $type,
            'items' => $model::orderBy($sortColumn)
                ->paginate(10)
                ->withQueryString(),
            'editingItem' => $editingItem,
            'accounts' => ChartAccount::orderBy('code')->get(),
            'financialGroups' => FinancialGroup::orderBy('type')
                ->orderBy('sort_order')
                ->orderBy('name')
                ->get(),
        ]);
    }

    public function store(Request $request, string $type)
    {
        $this->ensureCanManage($request);

        $class = $this->model($type);
        $class::create($this->validateData($request, $type));

        return redirect()
            ->route('accounting.master.index', $type)
            ->with('success', 'Master data berhasil ditambahkan.');
    }

    public function update(Request $request, string $type, int $id)
    {
        $this->ensureCanManage($request);

        $class = $this->model($type);
        $item = $class::findOrFail($id);
        $item->update($this->validateData($request, $type, $id));

        return redirect()
            ->route('accounting.master.index', $type)
            ->with(
                'success',
                'Master data diperbarui. Data terkait otomatis menggunakan data master terbaru.'
            );
    }

    public function destroy(Request $request, string $type, int $id)
    {
        $this->ensureCanManage($request);

        $class = $this->model($type);
        $item = $class::findOrFail($id);

        $dependencies = $this->dependencies($type, $item);

        if ($dependencies !== []) {
            return back()->with(
                'error',
                'Data tidak dapat dihapus karena masih terhubung dengan: '
                . implode(', ', $dependencies)
                . '. Gunakan status Inactive bila data tidak ingin digunakan lagi.'
            );
        }

        try {
            $item->delete();
        } catch (QueryException) {
            return back()->with(
                'error',
                'Data tidak dapat dihapus karena masih digunakan oleh data lain. Gunakan status Inactive.'
            );
        }

        return redirect()
            ->route('accounting.master.index', $type)
            ->with('success', 'Master data berhasil dihapus.');
    }

    private function dependencies(string $type, object $item): array
    {
        $used = [];

        $checks = match ($type) {
            'accounts' => [
                'COA turunan' => fn () => $item->children()->exists(),
                'Unit Pelayanan' => fn () => $item->serviceUnits()->exists(),
                'Kas & Bank' => fn () => $item->cashBankAccounts()->exists(),
                'Kategori Pengeluaran' => fn () => $item->expenseCategories()->exists(),
                'Pemasukan' => fn () => $item->receipts()->exists(),
                'Pengeluaran' => fn () => $item->expenses()->exists(),
                'Jurnal' => fn () => $item->journalLines()->exists(),
            ],
            'units' => [
                'Penerimaan' => fn () => $item->receipts()->exists(),
            ],
            'guarantors' => [
                'Penerimaan' => fn () => $item->receipts()->exists(),
            ],
            'cash-banks' => [
                'Penerimaan' => fn () => $item->receipts()->exists(),
                'Pengeluaran' => fn () => $item->expenses()->exists(),
            ],
            'expense-categories' => [
                'Pengeluaran' => fn () => $item->expenses()->exists(),
            ],
            'financial-groups' => [
                'Penjamin' => fn () => $item->guarantors()->exists(),
                'Kategori Pengeluaran' => fn () => $item->expenseCategories()->exists(),
            ],
            default => [],
        };

        foreach ($checks as $label => $check) {
            if ($check()) {
                $used[] = $label;
            }
        }

        return $used;
    }

    private function ensureCanManage(Request $request): void
    {
        $role = strtoupper(trim((string) ($request->user()?->accountingRole() ?? '')));

        abort_unless(
            in_array($role, ['KASIR', 'ACCOUNTING', 'IT'], true),
            403
        );
    }

    private function model(string $type)
    {
        abort_unless(isset($this->map[$type]), 404);

        return $this->map[$type];
    }

    private function validateData(
        Request $request,
        string $type,
        ?int $id = null
    ): array {
        return match ($type) {
            'accounts' => $request->validate([
                'code' => [
                    'required',
                    'max:30',
                    Rule::unique('chart_accounts', 'code')->ignore($id),
                ],
                'name' => ['required', 'max:150'],
                'type' => ['required', 'in:ASSET,LIABILITY,EQUITY,REVENUE,EXPENSE'],
                'parent_id' => [
                    'nullable',
                    'exists:chart_accounts,id',
                    Rule::notIn(array_filter([$id])),
                ],
                'normal_balance' => ['required', 'in:DEBIT,CREDIT'],
                'is_active' => ['required', 'boolean'],
            ]),
            'units' => $request->validate([
                'code' => [
                    'required',
                    'max:30',
                    Rule::unique('service_units', 'code')->ignore($id),
                ],
                'name' => ['required', 'max:150'],
                'revenue_account_id' => ['nullable', 'exists:chart_accounts,id'],
                'is_active' => ['required', 'boolean'],
            ]),
            'guarantors' => $request->validate([
                'code' => [
                    'required',
                    'max:30',
                    Rule::unique('guarantors', 'code')->ignore($id),
                ],
                'name' => ['required', 'max:150'],
                'category' => [
                    'required',
                    'in:SELF_PAY,BPJS,PRIVATE_INSURANCE,CORPORATE,OTHER',
                ],
                'financial_group_id' => ['required', 'exists:financial_groups,id'],
                'is_bpjs' => ['required', 'boolean'],
                'is_active' => ['required', 'boolean'],
            ]),
            'cash-banks' => $request->validate([
                'code' => [
                    'required',
                    'max:30',
                    Rule::unique('cash_bank_accounts', 'code')->ignore($id),
                ],
                'name' => ['required', 'max:150'],
                'type' => ['required', 'in:CASH,BANK'],
                'bank_name' => ['nullable', 'max:150'],
                'account_number' => ['nullable', 'max:100'],
                'chart_account_id' => ['required', 'exists:chart_accounts,id'],
                'is_active' => ['required', 'boolean'],
            ]),
            'expense-categories' => $request->validate([
                'code' => [
                    'required',
                    'max:30',
                    Rule::unique('expense_categories', 'code')->ignore($id),
                ],
                'name' => ['required', 'max:150'],
                'financial_group_id' => ['required', 'exists:financial_groups,id'],
                'expense_account_id' => ['required', 'exists:chart_accounts,id'],
                'is_active' => ['required', 'boolean'],
            ]),
            'financial-groups' => $request->validate([
                'code' => [
                    'required',
                    'max:40',
                    Rule::unique('financial_groups', 'code')->ignore($id),
                ],
                'name' => ['required', 'max:150'],
                'type' => ['required', 'in:INCOME,EXPENSE'],
                'sort_order' => ['required', 'integer', 'min:0', 'max:9999'],
                'is_active' => ['required', 'boolean'],
            ]),
        };
    }
}
