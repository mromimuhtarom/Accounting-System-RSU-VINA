<?php
namespace App\Http\Controllers;

use App\Models\Expense;
use App\Models\Receipt;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function __invoke(Request $request)
    {
        $role = strtoupper(trim((string) ($request->user()->accountingRole() ?? '')));
        $role = $role !== '' ? $role : null;
        $stats = [];
        $latestReceipts = collect();

        if ($role === 'KASIR') {
            $stats = [
                'today_count' => Receipt::where('cashier_id', $request->user()->id)->whereDate('transaction_date', today())->count(),
                'today_income' => Receipt::where('cashier_id', $request->user()->id)->where('status','ACTIVE')->whereDate('transaction_date', today())->sum('amount'),
            ];
        }

        if (in_array($role, ['ACCOUNTING','ATASAN','IT'])) {
            $incomeQuery = Receipt::where('status','ACTIVE')->whereYear('transaction_date', now()->year);
            $stats = [
                'income' => (clone $incomeQuery)->sum('amount'),
                'expense' => Expense::where('status','ACTIVE')->whereYear('expense_date', now()->year)->sum('amount'),
                'transactions' => (clone $incomeQuery)->count(),
                'bpjs' => (clone $incomeQuery)->whereHas('guarantor', fn($q) => $q->where('is_bpjs', true))->sum('amount'),
                'non_bpjs' => (clone $incomeQuery)->where(function ($q) {
                    $q->whereNull('guarantor_id')
                        ->orWhereHas('guarantor', fn ($g) => $g->where('is_bpjs', false));
                })->sum('amount'),
            ];
            $latestReceipts = Receipt::with(['account', 'cashier'])->where('status','ACTIVE')->latest('transaction_date')->latest('id')->limit(5)->get();
        }

        return view('dashboard', compact('role','stats','latestReceipts'));
    }
}
