<?php

namespace App\Http\Controllers\Cashier;

use App\Http\Controllers\Controller;
use App\Models\ChartAccount;
use App\Models\Receipt;
use Illuminate\Http\Request;

class ReceiptController extends Controller
{
    public function index(Request $request)
    {
        $query = Receipt::with(['account', 'journal', 'referralExpense'])
            ->where('cashier_id', $request->user()->id)
            ->latest('transaction_date')
            ->latest('id');

        if ($request->filled('date_from')) {
            $query->whereDate('transaction_date', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('transaction_date', '<=', $request->date_to);
        }

        if ($request->filled('account_id')) {
            $query->where('chart_account_id', $request->account_id);
        }

        if ($request->filled('search')) {
            $search = trim((string) $request->search);

            $query->where(function ($q) use ($search) {
                $q->where('transaction_no', 'like', "%{$search}%")
                    ->orWhere('income_code', 'like', "%{$search}%")
                    ->orWhere('notes', 'like', "%{$search}%")
                    ->orWhere('doctor_name', 'like', "%{$search}%")
                    ->orWhereHas('account', function ($account) use ($search) {
                        $account->where('code', 'like', "%{$search}%")
                            ->orWhere('name', 'like', "%{$search}%");
                    });
            });
        }

        return view('cashier.receipts.index', [
            'receipts' => $query->paginate(10)->withQueryString(),
            'accounts' => $this->accounts(),
        ]);
    }

    public function create()
    {
        return view('cashier.receipts.create', [
            'accounts' => $this->accounts(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $this->validatedData($request);
        $data['transaction_no'] = 'RCV-'
            . now()->format('YmdHis')
            . '-'
            . random_int(100, 999);
        $data['cashier_id'] = $request->user()->id;
        $data['status'] = 'ACTIVE';

        Receipt::create($data);

        return redirect()
            ->route('cashier.receipts.index')
            ->with('success', 'Pemasukan berhasil disimpan.');
    }

    public function edit(Request $request, Receipt $receipt)
    {
        $this->ensureOwnedByCashier($request, $receipt);

        if ($receipt->journal()->exists()) {
            return redirect()
                ->route('cashier.receipts.index')
                ->with('error', 'Transaksi sudah dijurnal oleh Accounting sehingga tidak dapat diedit oleh Kasir.');
        }

        return view('cashier.receipts.edit', [
            'receipt' => $receipt,
            'accounts' => $this->accounts(),
        ]);
    }

    public function update(Request $request, Receipt $receipt)
    {
        $this->ensureOwnedByCashier($request, $receipt);

        if ($receipt->journal()->exists()) {
            return redirect()
                ->route('cashier.receipts.index')
                ->with('error', 'Transaksi sudah dijurnal oleh Accounting sehingga tidak dapat diedit oleh Kasir.');
        }

        $receipt->update($this->validatedData($request));

        return redirect()
            ->route('cashier.receipts.index')
            ->with('success', 'Pemasukan berhasil diperbarui.');
    }

    public function destroy(Request $request, Receipt $receipt)
    {
        $this->ensureOwnedByCashier($request, $receipt);

        if ($receipt->journal()->exists()) {
            return redirect()
                ->route('cashier.receipts.index')
                ->with('error', 'Transaksi sudah dijurnal oleh Accounting sehingga tidak dapat dihapus oleh Kasir.');
        }

        if ($receipt->referralExpense()->exists()) {
            return redirect()
                ->route('cashier.receipts.index')
                ->with('error', 'Transaksi sudah memiliki pengeluaran referal sehingga tidak dapat dihapus.');
        }

        $receipt->delete();

        return redirect()
            ->route('cashier.receipts.index')
            ->with('success', 'Pemasukan berhasil dihapus.');
    }

    private function ensureOwnedByCashier(Request $request, Receipt $receipt): void
    {
        if ($request->user()->accountingRole() === 'IT') {
            return;
        }

        abort_unless(
            (int) $receipt->cashier_id === (int) $request->user()->id,
            403
        );
    }

    private function validatedData(Request $request): array
    {
        return $request->validate([
            'transaction_date' => ['required', 'date'],
            'chart_account_id' => ['required', 'exists:chart_accounts,id'],
            'notes' => ['required', 'string', 'max:1000'],
            'doctor_name' => ['nullable', 'string', 'max:150'],
            'hd' => ['nullable', 'string', 'max:100'],
            'rs' => ['nullable', 'string', 'max:100'],
            'amount' => ['required', 'numeric', 'gt:0'],
        ]);
    }

    private function accounts()
    {
        return ChartAccount::where('is_active', true)
            ->orderBy('code')
            ->get();
    }
}
