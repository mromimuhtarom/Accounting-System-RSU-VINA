@extends('layouts.app')

@section('content')
<div class="card">
    <h2>Trial Balance</h2>
    @include('reports.partials_date_filter')
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Account</th>
                    <th>Debit</th>
                    <th>Credit</th>
                    <th>Balance</th>
                </tr>
            </thead>
            <tbody>
            @forelse($rows as $r)
                <tr>
                    <td>{{ $r->code }}</td>
                    <td>{{ $r->name }}</td>
                    <td class="money">{{ number_format($r->debit, 2, ',', '.') }}</td>
                    <td class="money">{{ number_format($r->credit, 2, ',', '.') }}</td>
                    <td class="money">{{ number_format($r->balance, 2, ',', '.') }}</td>
                </tr>
            @empty
                <tr><td colspan="5" class="muted">Belum ada data.</td></tr>
            @endforelse
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="2">TOTAL</th>
                    <th class="money">{{ number_format($totals['debit'], 2, ',', '.') }}</th>
                    <th class="money">{{ number_format($totals['credit'], 2, ',', '.') }}</th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
    </div>
    <div class="pagination">{{ $rows->links() }}</div>
</div>
@endsection
