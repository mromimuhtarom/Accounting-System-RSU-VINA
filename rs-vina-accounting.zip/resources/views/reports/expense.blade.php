@extends('layouts.app')
@section('content')
<div class="card">
    <h2>Laporan Pengeluaran</h2>
    @include('reports.partials_date_filter')
    <h3>Total: Rp {{ number_format($total,0,',','.') }}</h3>
</div>
<div class="card">
    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>No</th>
                <th>Kategori</th>
                <th>Keterangan</th>
                <th>Nominal</th>
            </tr>
        </thead>
        <tbody>
            @foreach($rows as $r)
                <tr>
                    <td>{{ $r->expense_date->format('d-m-Y') }}</td>
                    <td>{{ $r->expense_no }}</td>
                    <td>{{ $r->category->name }}</td>
                    <td>{{ $r->description }}</td>
                    <td class="money">Rp {{ number_format($r->amount,0,',','.') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{ $rows->links() }}
</div>
@endsection
