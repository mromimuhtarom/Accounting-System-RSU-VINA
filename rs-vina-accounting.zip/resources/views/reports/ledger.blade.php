@extends('layouts.app')

@section('content')
<div class="card">
    <h2>General Ledger</h2>
    <form class="form-grid">
        <div class="field">
            <label>Account</label>
            <select name="account_id">
                <option value="">Pilih</option>
                @foreach($accounts as $a)
                    <option value="{{ $a->id }}" @selected(request('account_id') == $a->id)>
                        {{ $a->code }} - {{ $a->name }}
                    </option>
                @endforeach
            </select>
        </div>
        <div class="field">
            <label>Dari</label>
            <input type="date" name="date_from" value="{{ request('date_from') }}">
        </div>
        <div class="field">
            <label>Sampai</label>
            <input type="date" name="date_to" value="{{ request('date_to') }}">
        </div>
        <div>
            <button class="btn">Tampilkan</button>
        </div>
    </form>
</div>

@if($account)
<div class="card">
    <h3>{{ $account->code }} - {{ $account->name }}</h3>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Jurnal</th>
                    <th>Referensi</th>
                    <th>Keterangan</th>
                    <th>Debit</th>
                    <th>Credit</th>
                    <th>Balance</th>
                </tr>
            </thead>
            <tbody>
            @forelse($lines as $l)
                <tr>
                    <td>{{ $l->journal_date }}</td>
                    <td>{{ $l->journal_no }}</td>
                    <td>{{ $l->reference }}</td>
                    <td>{{ $l->description }}</td>
                    <td class="money">{{ number_format($l->debit, 2, ',', '.') }}</td>
                    <td class="money">{{ number_format($l->credit, 2, ',', '.') }}</td>
                    <td class="money">{{ number_format($l->running_balance, 2, ',', '.') }}</td>
                </tr>
            @empty
                <tr><td colspan="7" class="muted">Belum ada data jurnal untuk akun ini.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    <div class="pagination">{{ $lines->links() }}</div>
</div>
@endif
@endsection
