@extends('layouts.app')

@section('content')
<div class="page-head">
    <div>
        <h1 class="page-title">Edit Pemasukan</h1>
        <p class="page-sub">Perbaiki transaksi sebelum dijurnal. Kode mengikuti Chart of Accounts.</p>
    </div>
    <a class="btn" href="{{ route('cashier.receipts.index') }}">← Kembali</a>
</div>

<div class="card">
    <form method="POST" action="{{ route('cashier.receipts.update', $receipt) }}">
        @csrf
        @method('PUT')

        <div class="form-grid">
            <div class="field">
                <label>No Transaksi</label>
                <input value="{{ $receipt->transaction_no }}" disabled>
            </div>

            <div class="field">
                <label>Tanggal</label>
                <input type="date" name="transaction_date" value="{{ old('transaction_date', $receipt->transaction_date->format('Y-m-d')) }}" required>
            </div>

            <div class="field">
                <label>Kode / Chart of Account</label>
                <select name="chart_account_id" required>
                    <option value="">- Pilih Kode COA -</option>
                    @foreach($accounts as $account)
                        <option value="{{ $account->id }}" @selected((string) old('chart_account_id', $receipt->chart_account_id) === (string) $account->id)>
                            {{ $account->code }} - {{ $account->name }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="field" style="grid-column:1/-1">
                <label>Keterangan</label>
                <textarea name="notes" required>{{ old('notes', $receipt->notes) }}</textarea>
            </div>

            <div class="field">
                <label>N.Dokter</label>
                <input name="doctor_name" value="{{ old('doctor_name', $receipt->doctor_name) }}">
            </div>

            <div class="field">
                <label>HD</label>
                <input name="hd" value="{{ old('hd', $receipt->hd) }}">
            </div>

            <div class="field">
                <label>RS</label>
                <input name="rs" value="{{ old('rs', $receipt->rs) }}">
            </div>

            <div class="field">
                <label>Jumlah</label>
                <input type="number" min="1" step="0.01" name="amount" value="{{ old('amount', $receipt->amount) }}" required>
            </div>


        </div>

        <div style="margin-top:18px;display:flex;gap:10px">
            <button class="btn primary">Simpan Perubahan</button>
            <a class="btn" href="{{ route('cashier.receipts.index') }}">Batal</a>
        </div>
    </form>
</div>
@endsection
