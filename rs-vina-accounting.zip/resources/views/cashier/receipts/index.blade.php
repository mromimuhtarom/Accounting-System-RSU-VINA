@extends('layouts.app')

@section('content')
<div class="page-head">
    <div>
        <h1 class="page-title">Pemasukan Saya</h1>
        <p class="page-sub">Kode pemasukan menggunakan Chart of Accounts yang sama dengan Pengeluaran.</p>
    </div>
    <a class="btn primary" href="{{ route('cashier.receipts.create') }}">＋ Input Pemasukan</a>
</div>

<div class="card">
    <form class="form-grid" method="GET" action="{{ route('cashier.receipts.index') }}">
        <div class="field">
            <label>Dari Tanggal</label>
            <input type="date" name="date_from" value="{{ request('date_from') }}">
        </div>

        <div class="field">
            <label>Sampai Tanggal</label>
            <input type="date" name="date_to" value="{{ request('date_to') }}">
        </div>

        <div class="field">
            <label>Kode / COA</label>
            <select name="account_id">
                <option value="">Semua Kode</option>
                @foreach($accounts as $account)
                    <option value="{{ $account->id }}" @selected((string) request('account_id') === (string) $account->id)>
                        {{ $account->code }} - {{ $account->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="field">
            <label>Cari</label>
            <input name="search" value="{{ request('search') }}" placeholder="No transaksi, kode COA, keterangan, dokter">
        </div>

        <div style="align-self:end;display:flex;gap:8px">
            <button class="btn" type="submit">Filter</button>
            <a class="btn" href="{{ route('cashier.receipts.index') }}">Reset</a>
        </div>
    </form>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Kode</th>
                    <th>Keterangan</th>
                    <th>N.Dokter</th>
                    <th>HD</th>
                    <th>RS</th>
                    <th>Jumlah</th>
                    <th>Status Jurnal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            @forelse($receipts as $r)
                <tr>
                    <td>{{ $r->transaction_date->format('d-m-Y') }}</td>
                    <td>
                        <strong>{{ $r->account?->code ?? $r->income_code ?? '-' }}</strong>
                        @if($r->account)<div class="muted">{{ $r->account->name }}</div>@endif
                    </td>
                    <td>
                        {{ $r->notes ?: ($r->patient_name ?: $r->transaction_no) }}
                        <div class="muted">{{ $r->transaction_no }}</div>
                    </td>
                    <td>{{ $r->doctor_name ?: '-' }}</td>
                    <td>{{ $r->hd ?: '-' }}</td>
                    <td>{{ $r->rs ?: '-' }}</td>
                    <td class="money">Rp {{ number_format($r->amount, 0, ',', '.') }}</td>
                    <td>
                        @if($r->journal)
                            <span class="badge">Sudah Dijurnal</span>
                        @else
                            <span class="badge" style="background:#ecfdf3;color:#15803d">Belum Dijurnal</span>
                        @endif
                    </td>
                    <td>
                        @if(!$r->journal)
                            <div class="actions">
                                <a class="btn" href="{{ route('cashier.receipts.edit', $r) }}">Edit</a>

                                @if(!$r->referralExpense)
                                    <form method="POST" action="{{ route('cashier.receipts.destroy', $r) }}" onsubmit="return confirm('Hapus pemasukan {{ $r->transaction_no }}?')">
                                        @csrf
                                        @method('DELETE')
                                        <button class="btn danger" type="submit">Delete</button>
                                    </form>
                                @endif

                            </div>
                        @else
                            <span class="badge">Sudah dijurnal</span>
                        @endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="9" class="muted">Belum ada pemasukan.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>

    <div class="pagination">{{ $receipts->links() }}</div>
</div>
@endsection
