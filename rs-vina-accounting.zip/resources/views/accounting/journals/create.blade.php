@extends('layouts.app')
@section('content')
<div class="card">
    <h2>Jurnal Manual</h2>
    <form method="POST" action="{{ route('accounting.jurnal.store') }}">
        @csrf
        <div class="form-grid">
            <div class="field">
                <label>Tanggal</label>
                <input type="date" name="journal_date" value="{{ date('Y-m-d') }}">
            </div>
            <div class="field">
                <label>Referensi</label>
                <input name="reference">
            </div>
            <div class="field" style="grid-column:1/-1">
                <label>Keterangan</label>
                <input name="description" required>
            </div>
        </div>
        <h3>Baris Jurnal</h3>
        <p class="muted">MVP menyediakan 4 baris. Kosongkan baris yang tidak digunakan.</p>
        <table>
            <thead>
                <tr>
                    <th>Akun</th>
                    <th>Keterangan</th>
                    <th>Debit</th>
                    <th>Credit</th>
                </tr>
            </thead>
            <tbody>
                @for($i=0;$i<4;$i++)
                <tr>
                    <td>
                        <select name="lines[{{ $i }}][chart_account_id]">
                            <option value="">Pilih</option>
                            @foreach($accounts as $a)
                                <option value="{{ $a->id }}">{{ $a->code }} - {{ $a->name }}</option>
                            @endforeach
                        </select>
                    </td>
                    <td><input name="lines[{{ $i }}][description]"></td>
                    <td><input type="number" step="0.01" min="0" name="lines[{{ $i }}][debit]" value="0"></td>
                    <td><input type="number" step="0.01" min="0" name="lines[{{ $i }}][credit]" value="0"></td>
                </tr>
                @endfor
            </tbody>
        </table>
        <br>
        <button class="btn primary">Simpan Jurnal</button>
    </form>
</div>
@endsection
