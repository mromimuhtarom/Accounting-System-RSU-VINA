@extends('layouts.app')
@section('content')
<div class="card">
    <div class="actions">
        <h2 style="flex:1">Jurnal</h2>
        <a class="btn primary" href="{{ route('accounting.jurnal.create') }}">Jurnal Manual</a>
    </div>
</div>
<div class="card">
    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>No</th>
                <th>Referensi</th>
                <th>Keterangan</th>
                <th>User</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @foreach($journals as $j)
            <tr>
                <td>{{ $j->journal_date->format('d-m-Y') }}</td>
                <td>{{ $j->journal_no }}</td>
                <td>{{ $j->reference }}</td>
                <td>{{ $j->description }}</td>
                <td>{{ $j->creator->name }}</td>
                <td>
                    <a class="btn" href="{{ route('accounting.jurnal.show',$j) }}">Detail</a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    {{ $journals->links() }}
</div>
@endsection
