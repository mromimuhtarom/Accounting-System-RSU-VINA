@extends('layouts.app')
@section('content')
<div class="card">
    <h2>{{ $journal->journal_no }}</h2>
    <p>{{ $journal->journal_date->format('d-m-Y') }} | {{ $journal->reference }}</p>
    <p>{{ $journal->description }}</p>
    <table>
        <thead>
            <tr>
                <th>Akun</th>
                <th>Keterangan</th>
                <th>Debit</th>
                <th>Credit</th>
            </tr>
        </thead>
        <tbody>
            @foreach($journal->lines as $l)
            <tr>
                <td>{{ $l->account->code }} - {{ $l->account->name }}</td>
                <td>{{ $l->description }}</td>
                <td class="money">{{ number_format($l->debit,2,',','.') }}</td>
                <td class="money">{{ number_format($l->credit,2,',','.') }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
