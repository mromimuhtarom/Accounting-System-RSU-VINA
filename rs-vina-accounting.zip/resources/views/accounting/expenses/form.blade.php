<form method="POST" enctype="multipart/form-data" action="{{ $action }}">
    @csrf 
    @if($method==='PUT')
    @method('PUT')
    @endif
    <div class="form-grid"><div class="field">
        <label>Tanggal</label>
        <input type="date" name="expense_date" value="{{ old('expense_date',$expense?->expense_date?->format('Y-m-d') ?? date('Y-m-d')) }}" required>
    </div>
    <div class="field">
        <label>Kategori</label>
        <select name="expense_category_id" required>
            @foreach($categories as $x)
            <option value="{{ $x->id }}" @selected(old('expense_category_id',$expense?->expense_category_id)==$x->id)>{{ $x->name }}</option>
            @endforeach
        </select>
    </div>
    <div class="field">
        <label>COA Beban</label>
        <select name="chart_account_id" required>
            @foreach($accounts as $x)
            <option value="{{ $x->id }}" @selected(old('chart_account_id',$expense?->chart_account_id)==$x->id)>{{ $x->code }} - {{ $x->name }}</option>
            @endforeach
        </select>
    </div>
    <div class="field">
        <label>Nominal</label>
        <input type="number" step="0.01" min="1" name="amount" value="{{ old('amount',$expense?->amount) }}" required>
    </div>
    <div class="field">
        <label>Metode</label>
        <select name="payment_method">
            @foreach(['CASH'=>'Cash','TRANSFER'=>'Transfer','QRIS'=>'QRIS','CARD'=>'Debit/Kartu'] as $k=>$v)
            <option value="{{ $k }}" @selected(old('payment_method',$expense?->payment_method)===$k)>{{ $v }}</option>
            @endforeach
        </select>
    </div>
    <div class="field">
        <label>Kas / Bank</label>
        <select name="cash_bank_account_id">
            @foreach($cashBanks as $x)
            <option value="{{ $x->id }}" @selected(old('cash_bank_account_id',$expense?->cash_bank_account_id)==$x->id)>{{ $x->name }}</option>
            @endforeach
        </select>
    </div>
    <div class="field">
        <label>No Referensi</label>
        <input name="reference_no" value="{{ old('reference_no',$expense?->reference_no) }}">
    </div>
    <div class="field">
        <label>Attachment</label>
        <input type="file" name="attachment">
    </div>
    <div class="field" style="grid-column:1/-1">
        <label>Keterangan</label>
        <textarea name="description" required>{{ old('description',$expense?->description) }}</textarea>
    </div>
</div>
<button class="btn primary">Simpan</button>
</form>
