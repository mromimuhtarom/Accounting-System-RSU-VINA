<form method="POST" action="{{ $action }}">
    @csrf
    @if($method === 'PUT')
        @method('PUT')
    @endif

    <div class="form-grid">
        <div class="field">
            <label>Tanggal Pengeluaran</label>
            <input type="date" name="expense_date" value="{{ old('expense_date', $referral?->expense_date?->format('Y-m-d') ?? date('Y-m-d')) }}" required>
        </div>

        <div class="field" style="grid-column:1/-1">
            <label>Sesi / Transaksi Pemasukan</label>
            <select name="receipt_id" id="referralSession" required>
                <option value="">Pilih sesi pemasukan</option>
                @foreach($sessions as $s)
                    @php($used = $s->referralExpense && $s->referralExpense->id !== ($editingReferralId ?? null))
                    <option value="{{ $s->id }}" @selected(old('receipt_id', $referral?->receipt_id) == $s->id) @disabled($used)>
                        {{ $s->transaction_no }} · {{ $s->transaction_date->format('d-m-Y') }} · {{ $s->account?->code ?? $s->income_code ?? 'Tanpa Kode' }} · {{ \Illuminate\Support\Str::limit($s->notes ?: $s->patient_name, 70) }}{{ $used ? ' · SUDAH ADA REFERAL' : '' }}
                    </option>
                @endforeach
            </select>
            <div class="muted" style="margin-top:6px">Satu transaksi pemasukan hanya boleh memiliki satu referal.</div>
        </div>

        <div class="field">
            <label>Nama Penerima Referal</label>
            <input name="referral_recipient" value="{{ old('referral_recipient', $referral?->referral_recipient) }}" required placeholder="Nama dokter / pihak penerima">
        </div>

        <div class="field">
            <label>Nominal Referal</label>
            <input type="number" min="1" step="0.01" name="amount" value="{{ old('amount', $referral?->amount) }}" required>
        </div>

        <div class="field">
            <label>Metode Pembayaran</label>
            <select name="payment_method" required>
                @foreach(['CASH' => 'Cash', 'TRANSFER' => 'Transfer', 'QRIS' => 'QRIS', 'CARD' => 'Debit/Kartu'] as $key => $label)
                    <option value="{{ $key }}" @selected(old('payment_method', $referral?->payment_method) === $key)>{{ $label }}</option>
                @endforeach
            </select>
        </div>

        <div class="field">
            <label>Kas / Bank</label>
            <select name="cash_bank_account_id" required>
                @foreach($cashBanks as $x)
                    <option value="{{ $x->id }}" @selected(old('cash_bank_account_id', $referral?->cash_bank_account_id) == $x->id)>{{ $x->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="field">
            <label>No Referensi</label>
            <input name="reference_no" value="{{ old('reference_no', $referral?->reference_no) }}">
        </div>

        <div class="field" style="grid-column:1/-1">
            <label>Keterangan</label>
            <textarea name="description">{{ old('description', $referral?->description) }}</textarea>
        </div>
    </div>

    <div style="margin-top:18px;display:flex;gap:8px">
        <button class="btn primary">Simpan Referal</button>
        <a class="btn" href="{{ route('accounting.referrals.index') }}">Batal</a>
    </div>
</form>
