@extends('layouts.app')
@section('content')
<div class="page-head">
    <div><h1 class="page-title">Dashboard</h1><p class="page-sub">Ringkasan informasi keuangan rumah sakit</p></div>
    <span class="badge">{{ now()->translatedFormat('F Y') }}</span>
</div>

@if(!$role)
<div class="card" style="border-color:#f3c969;background:#fffaf0">
    <h3 class="section-title">Role Accounting belum terhubung</h3>
    <p class="muted" style="margin-bottom:0">Akun berhasil login, tetapi belum memiliki role KASIR, ACCOUNTING, ATASAN, atau IT pada aplikasi ACCOUNTING. Jalankan seeder lalu bersihkan cache konfigurasi agar menu dan dashboard tampil.</p>
</div>
@endif

@if($role==='KASIR')
<div class="stats-grid" style="grid-template-columns:repeat(2,minmax(0,1fr))">
    <div class="card stat-card"><div class="stat-icon green">＋</div><div class="stat-label">Transaksi Hari Ini</div><div class="stat">{{ number_format($stats['today_count']) }}</div><div class="stat-note">Input penerimaan oleh akun Anda</div></div>
    <div class="card stat-card"><div class="stat-icon blue">Rp</div><div class="stat-label">Nominal Hari Ini</div><div class="stat">Rp {{ number_format($stats['today_income'],0,',','.') }}</div><div class="stat-note">Total penerimaan aktif</div></div>
</div>
<div class="card">
    <h3 class="section-title">Input Pemasukan</h3>
    <p class="muted">Kasir hanya bertugas melakukan input penerimaan pasien. Receipt/print dan proses approval disiapkan untuk pengembangan berikutnya.</p>
    <a class="btn primary" href="{{ route('cashier.receipts.create') }}">＋ Input Pemasukan</a>
</div>
@endif

@if(in_array($role,['ACCOUNTING','ATASAN','IT']))
<div class="stats-grid">
    <div class="card stat-card"><div class="stat-icon green">↙</div><div class="stat-label">Total Pemasukan</div><div class="stat">Rp {{ number_format($stats['income'],0,',','.') }}</div><div class="stat-note">Tahun {{ now()->year }}</div></div>
    <div class="card stat-card"><div class="stat-icon red">↗</div><div class="stat-label">Total Pengeluaran</div><div class="stat">Rp {{ number_format($stats['expense'],0,',','.') }}</div><div class="stat-note">Tahun {{ now()->year }}</div></div>
    <div class="card stat-card"><div class="stat-icon blue">↗</div><div class="stat-label">Surplus / Defisit</div><div class="stat">Rp {{ number_format($stats['income']-$stats['expense'],0,',','.') }}</div><div class="stat-note">Pemasukan dikurangi pengeluaran</div></div>
    <div class="card stat-card"><div class="stat-icon purple">▤</div><div class="stat-label">Total Transaksi</div><div class="stat">{{ number_format($stats['transactions']) }}</div><div class="stat-note">Transaksi penerimaan aktif</div></div>
</div>

<div class="grid" style="grid-template-columns:minmax(0,2fr) minmax(280px,1fr)">
    <div class="card">
        <h3 class="section-title">Komposisi Pemasukan</h3>
        @php($all=max((float)$stats['income'],1))
        <div class="bar-list">
            <div class="bar-row"><strong>BPJS</strong><div class="bar-track"><div class="bar-fill" style="width:{{ min(100,($stats['bpjs']/$all)*100) }}%"></div></div><span>Rp {{ number_format($stats['bpjs'],0,',','.') }}</span></div>
            <div class="bar-row"><strong>Non-BPJS</strong><div class="bar-track"><div class="bar-fill" style="width:{{ min(100,($stats['non_bpjs']/$all)*100) }}%"></div></div><span>Rp {{ number_format($stats['non_bpjs'],0,',','.') }}</span></div>
        </div>
    </div>
    <div class="card">
        <h3 class="section-title">Akses Cepat</h3>
        <div class="quick-grid">
            @if(in_array($role,['ACCOUNTING','IT']))
            <a class="quick-link" href="{{ route('accounting.receipts.index') }}">↙ Pemasukan</a>
            <a class="quick-link" href="{{ route('accounting.pengeluaran.create') }}">↗ Input Pengeluaran</a>
            <a class="quick-link" href="{{ route('accounting.jurnal.create') }}">▤ Jurnal Manual</a>
            @endif
            <a class="quick-link" href="{{ route('reports.ledger') }}">≡ General Ledger</a>
            <a class="quick-link" href="{{ route('reports.income') }}">▧ Laporan Pemasukan</a>
            <a class="quick-link" href="{{ route('reports.expense') }}">▧ Laporan Pengeluaran</a>
        </div>
    </div>
</div>

<div class="card">
    <h3 class="section-title">Transaksi Pemasukan Terbaru</h3>
    <div class="table-wrap"><table><thead><tr><th>No Transaksi</th><th>Tanggal</th><th>Kode</th><th>Keterangan</th><th>N.Dokter</th><th>Kasir</th><th>Jumlah</th></tr></thead><tbody>
    @forelse($latestReceipts as $r)<tr><td><strong>{{ $r->transaction_no }}</strong></td><td>{{ $r->transaction_date->format('d M Y') }}</td><td>{{ $r->account?->code ?? $r->income_code ?? '-' }}</td><td>{{ $r->notes ?: ($r->patient_name ?: '-') }}</td><td>{{ $r->doctor_name ?: '-' }}</td><td>{{ $r->cashier?->name }}</td><td class="money">Rp {{ number_format($r->amount,0,',','.') }}</td></tr>@empty<tr><td colspan="7" class="muted">Belum ada transaksi.</td></tr>@endforelse
    </tbody></table></div>
</div>
@endif
@endsection
