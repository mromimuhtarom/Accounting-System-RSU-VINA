<?php

namespace Database\Seeders;

use App\Models\Application;
use App\Models\CashBankAccount;
use App\Models\ChartAccount;
use App\Models\ExpenseCategory;
use App\Models\FinancialGroup;
use App\Models\Guarantor;
use App\Models\Role;
use App\Models\ServiceUnit;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $app = Application::updateOrCreate(['code' => 'ACCOUNTING'], ['name' => 'Accounting System', 'is_active' => true]);
        $roles = collect([
            ['code' => 'KASIR', 'name' => 'Kasir'],
            ['code' => 'ACCOUNTING', 'name' => 'Accounting'],
            ['code' => 'ATASAN', 'name' => 'Atasan'],
            ['code' => 'IT', 'name' => 'IT'],
        ])->mapWithKeys(function ($r) use ($app) {
            $role = Role::updateOrCreate(['application_id' => $app->id, 'code' => $r['code']], ['name' => $r['name']]);
            return [$r['code'] => $role];
        });

        foreach ([
            ['email' => 'kasir@hospital.test', 'name' => 'Demo Kasir', 'role' => 'KASIR'],
            ['email' => 'accounting@hospital.test', 'name' => 'Demo Accounting', 'role' => 'ACCOUNTING'],
            ['email' => 'atasan@hospital.test', 'name' => 'Demo Atasan', 'role' => 'ATASAN'],
            ['email' => 'it@hospital.test', 'name' => 'Demo IT', 'role' => 'IT'],
        ] as $u) {
            $user = User::updateOrCreate(['email' => $u['email']], [
                'name' => $u['name'],
                'password' => Hash::make('password'),
                'is_active' => true,
            ]);
            $user->roles()->syncWithoutDetaching([$roles[$u['role']]->id]);
        }

        $coa = [
            ['code' => '1-1000', 'name' => 'Kas', 'type' => 'ASSET', 'normal_balance' => 'DEBIT'],
            ['code' => '1-1100', 'name' => 'Bank', 'type' => 'ASSET', 'normal_balance' => 'DEBIT'],
            ['code' => '1-1201', 'name' => 'Piutang Non-BPJS', 'type' => 'ASSET', 'normal_balance' => 'DEBIT'],
            ['code' => '1-1202', 'name' => 'Piutang BPJS', 'type' => 'ASSET', 'normal_balance' => 'DEBIT'],
            ['code' => '2-1000', 'name' => 'Hutang', 'type' => 'LIABILITY', 'normal_balance' => 'CREDIT'],
            ['code' => '3-1000', 'name' => 'Modal', 'type' => 'EQUITY', 'normal_balance' => 'CREDIT'],
            ['code' => '3-2000', 'name' => 'Prive', 'type' => 'EQUITY', 'normal_balance' => 'DEBIT'],
            ['code' => '4-1001', 'name' => 'Pendapatan IGD', 'type' => 'REVENUE', 'normal_balance' => 'CREDIT'],
            ['code' => '4-1002', 'name' => 'Pendapatan Rawat Inap', 'type' => 'REVENUE', 'normal_balance' => 'CREDIT'],
            ['code' => '4-1003', 'name' => 'Pendapatan Poli', 'type' => 'REVENUE', 'normal_balance' => 'CREDIT'],
            ['code' => '4-1004', 'name' => 'Pendapatan Laboratorium', 'type' => 'REVENUE', 'normal_balance' => 'CREDIT'],
            ['code' => '4-1005', 'name' => 'Pendapatan Apotik', 'type' => 'REVENUE', 'normal_balance' => 'CREDIT'],
            ['code' => '5-1001', 'name' => 'Beban Honor', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1002', 'name' => 'Beban Transfusi', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1003', 'name' => 'Beban CT Scan', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1004', 'name' => 'Beban Entertainment', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1005', 'name' => 'Beban Obat', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1006', 'name' => 'Beban Dapur', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1007', 'name' => 'Beban Minyak', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1008', 'name' => 'Beban ATK', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1009', 'name' => 'Beban Pemeliharaan', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1010', 'name' => 'Beban Listrik', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1011', 'name' => 'Beban Air', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1012', 'name' => 'Beban Telepon', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1013', 'name' => 'Beban Gaji', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1014', 'name' => 'Beban Referal', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
            ['code' => '5-1099', 'name' => 'Beban Lain-lain', 'type' => 'EXPENSE', 'normal_balance' => 'DEBIT'],
        ];
        foreach ($coa as $row) {
            ChartAccount::updateOrCreate(['code' => $row['code']], array_merge($row, ['is_active' => true]));
        }
        $account = fn (string $code) => ChartAccount::where('code', $code)->firstOrFail()->id;

        $groups = [
            ['code' => 'REV_SERVICE', 'name' => 'Pendapatan Pelayanan', 'type' => 'INCOME', 'sort_order' => 10],
            ['code' => 'REV_BPJS', 'name' => 'Pendapatan BPJS', 'type' => 'INCOME', 'sort_order' => 20],
            ['code' => 'REV_GUARANTOR', 'name' => 'Asuransi & Penjamin', 'type' => 'INCOME', 'sort_order' => 30],
            ['code' => 'EXP_HR', 'name' => 'Beban SDM', 'type' => 'EXPENSE', 'sort_order' => 10],
            ['code' => 'EXP_MEDICAL', 'name' => 'Beban Medis', 'type' => 'EXPENSE', 'sort_order' => 20],
            ['code' => 'EXP_OPERATIONAL', 'name' => 'Beban Operasional', 'type' => 'EXPENSE', 'sort_order' => 30],
        ];
        foreach ($groups as $group) {
            FinancialGroup::updateOrCreate(['code' => $group['code']], array_merge($group, ['is_active' => true]));
        }
        $group = fn (string $code) => FinancialGroup::where('code', $code)->firstOrFail()->id;

        $units = [
            ['IGD', 'IGD', '4-1001'],
            ['RAWAT_INAP', 'Rawat Inap / Opname', '4-1002'],
            ['SARAF', 'Poli Saraf', '4-1003'],
            ['BEDAH', 'Poli Bedah', '4-1003'],
            ['ANAK', 'Poli Anak', '4-1003'],
            ['OBGYN', 'Poli OBGYN', '4-1003'],
            ['THT', 'Poli THT', '4-1003'],
            ['LAB', 'Laboratorium', '4-1004'],
            ['APOTIK', 'Apotik', '4-1005'],
            ['PENYAKIT_DALAM', 'Penyakit Dalam', '4-1003'],
            ['JIWA', 'Poli Jiwa', '4-1003'],
            ['POLI_LAIN', 'Poli Lain-lain', '4-1003'],
        ];
        foreach ($units as [$code, $name, $rev]) {
            ServiceUnit::updateOrCreate(['code' => $code], [
                'name' => $name,
                'revenue_account_id' => $account($rev),
                'is_active' => true,
            ]);
        }

        $guarantors = [
            ['UMUM', 'Umum / Pribadi', 'SELF_PAY', 'REV_SERVICE'],
            ['BPJS', 'BPJS Kesehatan', 'BPJS', 'REV_BPJS'],
            ['JAMSOSTEK', 'Jamsostek / BPJS Ketenagakerjaan', 'OTHER', 'REV_GUARANTOR'],
            ['JASA_RAHARJA', 'Jasa Raharja', 'OTHER', 'REV_GUARANTOR'],
            ['ALLIANZ', 'Allianz', 'PRIVATE_INSURANCE', 'REV_GUARANTOR'],
            ['SINARMAS', 'Sinar Mas', 'PRIVATE_INSURANCE', 'REV_GUARANTOR'],
            ['ADMEDIKA', 'AdMedika', 'PRIVATE_INSURANCE', 'REV_GUARANTOR'],
            ['GRAB', 'Grab', 'CORPORATE', 'REV_GUARANTOR'],
            ['KFC', 'KFC', 'CORPORATE', 'REV_GUARANTOR'],
            ['CARREFOUR', 'Carrefour', 'CORPORATE', 'REV_GUARANTOR'],
            ['SYNTEK', 'Syntek', 'CORPORATE', 'REV_GUARANTOR'],
            ['LAIN', 'Penjamin Lainnya', 'OTHER', 'REV_GUARANTOR'],
        ];
        foreach ($guarantors as [$code, $name, $category, $groupCode]) {
            Guarantor::updateOrCreate(['code' => $code], [
                'name' => $name,
                'category' => $category,
                'financial_group_id' => $group($groupCode),
                'is_bpjs' => $category === 'BPJS',
                'is_active' => true,
            ]);
        }

        CashBankAccount::updateOrCreate(['code' => 'KAS_UTAMA'], [
            'name' => 'Kas Utama',
            'type' => 'CASH',
            'chart_account_id' => $account('1-1000'),
            'is_active' => true,
        ]);
        CashBankAccount::updateOrCreate(['code' => 'BANK_UTAMA'], [
            'name' => 'Bank Utama',
            'type' => 'BANK',
            'bank_name' => 'Bank Rumah Sakit',
            'chart_account_id' => $account('1-1100'),
            'is_active' => true,
        ]);

        $expenses = [
            ['HONOR', 'Honor', '5-1001', 'EXP_HR'],
            ['TRANSFUSI', 'Transfusi', '5-1002', 'EXP_MEDICAL'],
            ['CT_SCAN', 'CT Scan', '5-1003', 'EXP_MEDICAL'],
            ['ENTERTAINMENT', 'Entertainment', '5-1004', 'EXP_OPERATIONAL'],
            ['OBAT', 'Obat', '5-1005', 'EXP_MEDICAL'],
            ['DAPUR', 'Dapur', '5-1006', 'EXP_OPERATIONAL'],
            ['MINYAK', 'Minyak', '5-1007', 'EXP_OPERATIONAL'],
            ['ATK', 'ATK', '5-1008', 'EXP_OPERATIONAL'],
            ['PEMELIHARAAN', 'Pemeliharaan', '5-1009', 'EXP_OPERATIONAL'],
            ['LISTRIK', 'Listrik', '5-1010', 'EXP_OPERATIONAL'],
            ['AIR', 'Air', '5-1011', 'EXP_OPERATIONAL'],
            ['TELEPON', 'Telepon', '5-1012', 'EXP_OPERATIONAL'],
            ['GAJI', 'Gaji', '5-1013', 'EXP_HR'],
            ['REFERAL', 'Referal', '5-1014', 'EXP_OPERATIONAL'],
            ['LAIN', 'Lain-lain', '5-1099', 'EXP_OPERATIONAL'],
        ];
        foreach ($expenses as [$code, $name, $acc, $groupCode]) {
            ExpenseCategory::updateOrCreate(['code' => $code], [
                'name' => $name,
                'financial_group_id' => $group($groupCode),
                'expense_account_id' => $account($acc),
                'is_active' => true,
            ]);
        }
    }
}
